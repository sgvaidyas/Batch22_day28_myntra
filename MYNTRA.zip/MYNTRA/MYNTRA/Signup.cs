﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MYNTRA
{
    public partial class Signup : Form
    {
        string email;

        public Signup()
        {
            InitializeComponent();
        }
        public Signup(string email)
        {
            InitializeComponent();
            this.email = email;
        }

        private void Signup_Load(object sender, EventArgs e)
        {
            txtemail.Text = email;
        }
    }
}
