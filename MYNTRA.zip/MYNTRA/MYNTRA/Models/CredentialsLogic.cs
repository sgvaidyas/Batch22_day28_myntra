﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MYNTRA.Models
{
    class CredentialsLogic
    {
        string connstr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;

        public int isvaliduser(string usr,string passd,out Customer c)
        {
            int valid = 0;
            //if returns 0-> the email doesnt exist in table
            //if returns 1-> the email exist in table but password is wrong 
            //if returns 2-> the email and password is proper

            c = new Customer();
            SqlConnection conn = new SqlConnection(connstr);
            string sql = "select * from Customers where Emailid='"+usr +"'";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    valid = 1;
                    if (reader.GetValue(1).ToString() == passd)
                    {
                        valid = 2;
                        c.Email = reader.GetValue(0).ToString();
                        c.Password = reader.GetValue(1).ToString();
                        c.Fullname = reader.GetValue(2).ToString();
                        c.Phone = reader.GetValue(3).ToString();
                        c.Address = reader.GetValue(4).ToString();
                        c.SecurityAns = reader.GetValue(5).ToString();
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                valid = -1;
            }
            finally
            {
                conn.Close();
            }
            return valid;
        }
       
    }
}
